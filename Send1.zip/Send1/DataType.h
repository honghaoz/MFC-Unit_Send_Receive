typedef unsigned char	INT8U;
//typedef char			INT8;
typedef unsigned short	INT16U;
typedef short			INT16;
typedef unsigned int	INT32U;
typedef int				INT32;